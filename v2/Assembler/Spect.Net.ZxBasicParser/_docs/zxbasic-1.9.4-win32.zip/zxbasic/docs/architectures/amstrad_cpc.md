#Amstrad CPC

## documentation 
* http://cpcwiki.eu/index.php/Technical_documentation
* www.cpcmania.com/Docs/Programming/Programming.htm

## games with sources 
* http://www.mojontwins.com/juegos_mojonos/uwol-2-cpc/
* http://www.mojontwins.com/juegos_mojonos/lala-prologue-cpc/

## Locomotive Basic 
* http://www.qsl.net/hb9xch/computer/amstrad/locomotivebasic.html
* http://www.grimware.org/doku.php/documentations/software/locomotive.basic/start
* http://www.cpcwiki.eu/index.php/Locomotive_BASIC
* http://rosettacode.org/wiki/Category:Locomotive_Basic


