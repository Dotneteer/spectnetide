#Ondra

* http://www.old-computers.com/museum/computer.asp?c=612
* http://www.8bity.cz/2011/tesla-ondra-uzivatelske-prirucky/
* http://www.sapi.cz/ondra/ondra.php


