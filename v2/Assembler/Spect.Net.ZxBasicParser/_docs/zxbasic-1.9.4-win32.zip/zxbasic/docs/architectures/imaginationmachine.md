#ImaginationMachine

* http://en.wikipedia.org/wiki/APF_Imagination_Machine
* http://www.old-computers.com/museum/computer.asp?c=584&st=1


