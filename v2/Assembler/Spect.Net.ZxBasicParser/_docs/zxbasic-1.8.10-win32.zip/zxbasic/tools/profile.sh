#!/bin/bash

python -m cProfile "$@"

