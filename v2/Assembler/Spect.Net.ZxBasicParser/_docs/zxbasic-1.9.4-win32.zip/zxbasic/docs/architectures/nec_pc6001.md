#NEC PC6001

* http://translate.google.com/translate?sl=auto&tl=en&js=n&prev=_t&hl=en&ie=UTF-8&layout=2&eotf=1&u=http%3A%2F%2Fwww.openspc2.org%2FBASIC%2FHTML%2FPC-6001%255BN60BASIC%255D.html&act=url ( http://www.openspc2.org/BASIC/HTML/PC-6001%5BN60BASIC%5D.html )


