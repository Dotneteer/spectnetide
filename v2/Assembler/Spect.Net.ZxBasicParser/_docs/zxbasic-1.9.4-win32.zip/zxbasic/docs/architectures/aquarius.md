#Aquarius

* http://www.retro-zone.org/documentation/mattel_aquarius_extendedbasicmanual/complete_manual.html
* http://tech.groups.yahoo.com/group/mattelaquarius/
* http://www.vdsteenoven.com/aquarius/malloc.html
* http://www.vdsteenoven.com/aquarius/mempointer.html
* http://www.vdsteenoven.com/aquarius/iomap.html
* http://www.vdsteenoven.com/aquarius/psgprog.html
* http://www.vdsteenoven.com/aquarius/hndcntrl.html
* http://archive.kontek.net/aqemu.classicgaming.gamespy.com/aqfaq2.htm


