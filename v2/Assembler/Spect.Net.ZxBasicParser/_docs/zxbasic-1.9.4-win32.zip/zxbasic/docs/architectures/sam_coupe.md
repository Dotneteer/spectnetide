#Sam Coupe

* http://www.mono.org/~unc/Coupe/Tech/basic.html
* http://sam.speccy.cz/basic.html
* http://sam.speccy.cz/systech/sam_coupe_tech-man_v3-0.pdf
* http://sam.speccy.cz/systech/unofficial_tech-man_v1-0.txt
* http://www.worldofsam.org


