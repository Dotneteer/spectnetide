#TaitoDarius

* http://mamedev.org/source/src/mame/drivers/darius.c.html
* http://mrjester.hapisan.com/04_MC68/
* http://www.scm.tees.ac.uk/users/u0000408/CSY/68Kexamples.htm
* http://tict.ticalc.org/docs/68kguide.txt
* http://en.wikibooks.org/wiki/68000_Assembly 
* http://68k.hax.com/


