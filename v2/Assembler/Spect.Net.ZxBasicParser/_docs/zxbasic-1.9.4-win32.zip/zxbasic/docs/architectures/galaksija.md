#Galaksija

* http://github.com/opicron/mame/blob/master/mess/drivers/galaxy.c
* http://en.wikipedia.org/wiki/Galaksija_BASIC
* http://www.dejanristanovic.com/rac1/rac1umet.htm (serbian - http://translate.google.com/translate?sl=sr&tl=en&js=n&prev=_t&hl=en&ie=UTF-8&layout=2&eotf=1&u=http%3A%2F%2Fwww.dejanristanovic.com%2Frac1%2Frac1umet.htm&act=url )
* http://web.archive.org/web/20080121071246/www.paralax.co.yu/pr83.htm
* http://retro.foing-nova.hr/galutil.htm
* http://simonowen.com/sam/galemu/
* http://solair.eunet.rs/~jovkovic/galaxy/
* http://galaksija.petnica.rs/index.php/
* http://galaksija.petnica.rs/index.php/Documentation
* http://www.dejanristanovic.com/rac1/rac1umet.htm
* http://retrospec.sgn.net/users/tomcat/Galaksija/MagScans/
* http://www.galaksija.org/
* http://emulator.galaksija.org/
* http://www.tablix.org/~avian/blog/articles/galaksija/
* http://retrospec.sgn.net/users/tomcat/Galaksija/
* http://retrospec.sgn.net/users/tomcat/yu/Galaksija_list.php
* http://www.youtube.com/watch?v=LQvS7gsJ0ik


