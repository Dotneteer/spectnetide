#Wonderswan

* http://en.wikipedia.org/wiki/WonderSwan
* http://www.asahi-net.or.jp/~cs8k-cyu/ww/index.html


