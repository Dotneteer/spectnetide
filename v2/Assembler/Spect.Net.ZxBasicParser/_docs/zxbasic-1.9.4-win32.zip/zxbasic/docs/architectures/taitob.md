#TaitoB

* http://www.system16.com/hardware.php?id=660
* http://mamedev.org/source/src/mame/drivers/taito_b.c.html
* http://mamedev.org/source/src/mame/video/taito_b.c.html


