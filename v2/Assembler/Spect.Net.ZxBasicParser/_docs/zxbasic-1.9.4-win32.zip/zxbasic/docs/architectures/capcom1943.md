#Capcom1943

* http://mamedev.org/source/src/mame/drivers/1943.c.html


