#FrereGustav.bas

```
 Program: freregustav.bas
```
```
REM Frere Gustav, from the ZX Spectrum 48K Manual, Chapter 19

PRINT "Frere Gustav"

BEEP 1, 0: BEEP 1, 2: BEEP .5, 3: BEEP .5, 2: BEEP 1, 0
BEEP 1, 0: BEEP 1, 2: BEEP .5, 3: BEEP .5, 2: BEEP 1, 0

BEEP 1, 3: BEEP 1, 5: BEEP 2, 7
BEEP 1, 3: BEEP 1, 5: BEEP 2, 7

BEEP .75, 7: BEEP .25, 8: BEEP .5, 7: BEEP .5, 5: BEEP .5, 3: BEEP .5, 2: BEEP 1, 0
BEEP .75, 7: BEEP .25, 8: BEEP .5, 7: BEEP .5, 5: BEEP .5, 3: BEEP .5, 2: BEEP 1, 0

BEEP 1, 0: BEEP 1, -5: BEEP 2, 0
BEEP 1, 0: BEEP 1, -5: BEEP 2, 0
```
