#Colecovision

* http://www.colecovisionzone.com/page/coleco%20industries/programmers.html
* http://pdroms.de/news/coleco-vision/
* http://atarihq.com/danb/files/CV-Tech.txt
* http://www.colecovision.eu/ColecoVision/development/tutorial1.shtml
* http://mamedev.org/source/src/mess/drivers/coleco.c.html
* http://mamedev.org/source/src/mess/machine/coleco.c.html


