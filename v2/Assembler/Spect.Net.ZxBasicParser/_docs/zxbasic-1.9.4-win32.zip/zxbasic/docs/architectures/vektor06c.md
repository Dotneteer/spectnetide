#Vektor06c

* http://en.wikipedia.org/wiki/Vector-06C
* https://code.google.com/p/vector06cc/
* http://www.vector06c.narod.ru/
* http://emu80.org/dev/dev_v.html
* http://www.youtube.com/watch?v=rlTQQQPUZ2Y&list=PL8750FB243935EDE2


