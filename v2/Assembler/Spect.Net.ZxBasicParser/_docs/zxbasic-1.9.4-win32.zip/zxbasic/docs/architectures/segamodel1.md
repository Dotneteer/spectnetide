#SegaModel1

* http://mamedev.org/source/src/mame/drivers/model1.c.html


