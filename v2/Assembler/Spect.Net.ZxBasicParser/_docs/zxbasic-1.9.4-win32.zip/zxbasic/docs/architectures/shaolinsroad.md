#ShaolinsRoad

* http://mamedev.org/source/src/mame/drivers/shaolins.c.html


