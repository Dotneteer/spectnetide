#Amiga 500

## Amos 
From http://www.clickteam.com/eng/downloadcenter.php?i=58 (redirecting too fast) some Amos sources are available:
* http://www.clickteam.com/webftp/files/2/5/AMOSCompiler.zip
* http://www.clickteam.com/webftp/files/2/5/AMOS1_23.zip
* http://www.clickteam.com/webftp/files/2/5/AMOS1_3.zip
* http://www.clickteam.com/webftp/files/2/5/EasyAMOS.zip
* http://stos.atari.st/theme_2_1.html

## Blitz-Basic 
* http://www.blitz-2000.co.uk/

## Amiga-Basic 
* http://www.amigacoding.com/index.php/AmigaBASIC


