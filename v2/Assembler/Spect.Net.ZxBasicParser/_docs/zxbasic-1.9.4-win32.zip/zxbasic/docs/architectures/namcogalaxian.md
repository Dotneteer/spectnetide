#NamcoGalaxian

games: Galaxian, Moon Alien Part 2, King and Balloon, Moon Cresta, Moon Shuttle, Frogger, Amidar, 
Turtles, Scramble, The End, Super Cobra, Dark Planet, Lost Tomb, Dambusters

* http://en.wikipedia.org/wiki/Namco_Galaxian
* http://www.koders.com/c/fid3A82BC24A0AB30BB5AD0413EA2F7BE447FD5F51F.aspx (./drivers/galaxian.c)
* http://www.koders.com/c/fidBB9EE60046A355F8BCB932F3C0DFB22E5200DE93.aspx (./vidhrdw/vid_galaxian.c )
* http://mamedev.org/source/src/mame/drivers/galaxian.c.html
* http://mamedev.org/source/src/mame/video/galaxian.c.html
* http://mamedev.org/source/src/mame/audio/galaxian.c.html


