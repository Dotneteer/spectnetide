#LET

Let sentence is used to assign a value to a variable or array element. It can be omitted. E.g.:
```
LET a = 5
```
which can be also written as:
```
a = 5
```

##Remarks
* This sentence is 100% Sinclair BASIC Compatible
