#EpochSuperCassetteVision

* https://github.com/mamedev/mame/blob/master/src/mess/drivers/scv.c
* http://homepage3.nifty.com/takeda-toshiya/scv
* http://homepage3.nifty.com/takeda-toshiya/common
* http://www.old-computers.com/museum/computer.asp?st=2&c=844
* http://www.videogameconsolelibrary.com/pg80-super_cass_vis.htm


