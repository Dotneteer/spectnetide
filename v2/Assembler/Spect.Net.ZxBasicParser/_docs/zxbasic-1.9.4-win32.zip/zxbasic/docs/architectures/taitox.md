#TaitoX

* http://mamedev.org/source/src/mame/drivers/taito_x.c.html


