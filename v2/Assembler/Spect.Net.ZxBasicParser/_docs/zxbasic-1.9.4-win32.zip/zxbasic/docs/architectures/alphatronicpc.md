#AlphatronicPC

* http://www.old-computers.com/museum/computer.asp?st=1&c=241


