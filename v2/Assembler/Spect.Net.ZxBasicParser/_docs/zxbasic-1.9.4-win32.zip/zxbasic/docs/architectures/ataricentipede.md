#AtariCentipede

games made for this machine: Centipede, Warlords, Millipede, Maze Invaders, Bulls Eye Darts

* http://mamedev.org/source/src/mame/drivers/centiped.c.html


