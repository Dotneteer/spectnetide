#WorldCup90

* http://mamedev.org/source/src/mame/drivers/wc90.c.html
* http://mamedev.org/source/src/mame/drivers/wc90b.c.html
* http://mamedev.org/source/src/mame/video/wc90.c.html
* http://mamedev.org/source/src/mame/video/wc90b.c.html
* http://mamedev.org/source/src/emu/sound/2608intf.c.html
* http://www.koders.com/c/fidB89C064119164D15786137D73E025AB11E6C3D64.aspx
* http://www.koders.com/c/fidACAD9405AF6265DA3937E5EBF4C3FBB60E30D628.aspx


