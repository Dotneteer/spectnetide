#TaitoL

* http://mamedev.org/source/src/mame/drivers/taito_l.c.html


