#Tecmo

Tecmo hardware (z80) (games: Rygar, Silkworm, Gemini Wing)
* http://mamedev.org/source/src/mame/drivers/tecmo.c.html


