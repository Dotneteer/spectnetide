#IBM PC-XT

* http://www.freebasic.net/ may have interesting documentation about cross compiling from basic, and targeting hardware like IBM PC-XT


