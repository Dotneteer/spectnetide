#SegaOutrun

* http://www.system16.com/hardware.php?id=697&gid=1843#1843


