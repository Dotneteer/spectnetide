#SegaModel3

* http://mamedev.org/source/src/mame/drivers/model3.c.html


