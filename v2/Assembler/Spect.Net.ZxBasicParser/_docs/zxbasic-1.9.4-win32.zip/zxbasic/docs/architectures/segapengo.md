#SegaPengo

* http://umlautllama.com/projects/pacdocs/text/pengo.mmap
* http://mamedev.org/source/src/mame/drivers/pengo.c.html
* http://mamedev.org/source/src/emu/sound/namco.c.html


