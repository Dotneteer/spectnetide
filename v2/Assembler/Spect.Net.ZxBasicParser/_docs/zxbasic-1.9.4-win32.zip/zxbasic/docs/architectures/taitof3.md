#TaitoF3

* http://mamedev.org/source/src/mame/drivers/taito_f3.c.html


