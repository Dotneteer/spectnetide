#Pasopia5

* http://www.openspc2.org/BASIC/HTML/PASOPIA5%5BBASIC%5D*.html
* http://s-sasaji.ddo.jp/pccata/toshiba.htm


