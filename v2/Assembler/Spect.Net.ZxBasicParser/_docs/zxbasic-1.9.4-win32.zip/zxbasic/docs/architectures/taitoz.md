#TaitoZ

* http://mamedev.org/source/src/mame/drivers/taito_z.c.html


