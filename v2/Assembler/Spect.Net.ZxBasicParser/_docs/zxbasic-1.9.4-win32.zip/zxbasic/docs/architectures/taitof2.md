#TaitoF2

* http://www.system16.com/hardware.php?id=653&gid=1604#1604


