#NamcoPacMan

* http://mamedev.org/source/src/mame/drivers/pacman.c.html
* http://www.ascotti.org/programming/pie/hardware.htm
* http://www.gadgetfactory.net/2012/05/zx-spectrum-manic-miner-on-pacman-hardware/
* http://www.system16.com/hardware.php?id=514
* http://www.youtube.com/watch?v=mhbXHCYATbY
* http://www.bytemaniacos.com/?p=2089
* http://home.comcast.net/~jpittman2/pacman/pacmandossier.html#Chapter_1
* http://cubeman.org/arcade-source/pacman.asm
* http://umlautllama.com/projects/pacdocs/
* http://www.csh.rit.edu/~jerry/arcade/pacman/
* http://www.csh.rit.edu/~jerry/arcade/pacman/hangly.html
* http://www.csh.rit.edu/~jerry/arcade/age/


