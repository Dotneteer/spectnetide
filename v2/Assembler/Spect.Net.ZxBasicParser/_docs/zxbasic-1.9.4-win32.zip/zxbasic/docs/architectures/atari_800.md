#Atari 800

* http://en.wikipedia.org/wiki/Atari_BASIC
* http://atari.kensclassics.org/a8programming.html


