#TaitoH

* http://mamedev.org/source/src/mame/drivers/taito_h.c.html


