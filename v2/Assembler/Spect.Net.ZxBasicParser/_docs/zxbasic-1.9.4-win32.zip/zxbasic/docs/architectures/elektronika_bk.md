#Elektronika BK

Some information about Vilnius Basic at http://en.wikipedia.org/wiki/Vilnius_BASIC


