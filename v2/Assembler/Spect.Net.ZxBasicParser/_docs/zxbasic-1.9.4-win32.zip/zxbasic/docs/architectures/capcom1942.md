#Capcom1942

* http://mamedev.org/source/src/mame/drivers/1942.c.html


