#Tutorials

This is a list of programming tutorials for ZX BASIC.

##How to Write a Pac Man Clone (ZX Basic Project from the beginning)

Author: Britlion<br />
Link: [http://goo.gl/4jPd5](http://goo.gl/4jPd5)

##Making ZX Basic to work with Tommy Gun

Author: Boriel<br />
Link: [http://www.boriel.com/forum/how-to-tutorials/making-zx-basic-to-work-with-tommy-gun-t329.html](http://www.boriel.com/forum/how-to-tutorials/making-zx-basic-to-work-with-tommy-gun-t329.html)

##How to Use Inline Assembly

Author: Britlion<br />
Link: [http://goo.gl/Iw32U](http://goo.gl/Iw32U)

##ZX Basic + Fourspriter (Spanish)

Author: na_th_an<br />
Link: [http://tcyr.wordpress.com/tutoriales/](http://tcyr.wordpress.com/tutoriales/)<br />
(Don't forget you can get auto translation: via [Google](http://translate.google.com/translate?hl=en&sl=auto&tl=en&u=http%3A%2F%2Ftcyr.wordpress.com%2Ftutoriales%2F))

##Fondos vectoriales con SUVLEIR 3.0 (Spanish)

Author: na_th_an<br />
Link: [http://tcyr.wordpress.com/2012/03/07/suvleir-3-0-super-ultra-vector-library-experience-inspire-redux-3-0/](http://tcyr.wordpress.com/2012/03/07/suvleir-3-0-super-ultra-vector-library-experience-inspire-redux-3-0/)
and via [Google](http://translate.google.com/translate?sl=auto&tl=en&js=n&prev=_t&hl=en&ie=UTF-8&layout=2&eotf=1&u=http%3A%2F%2Ftcyr.wordpress.com%2F2012%2F03%2F07%2Fsuvleir-3-0-super-ultra-vector-library-experience-inspire-redux-3-0%2F&act=url)

##Using Beepola with ZX BASIC

Author: LTee<br />
Link: [http://www.boriel.com/forum/how-to-tutorials/using-beepola-with-zx-basic-t660.html](http://www.boriel.com/forum/how-to-tutorials/using-beepola-with-zx-basic-t660.html)
