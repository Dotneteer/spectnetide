#SNES

* http://en.wikibooks.org/wiki/Super_NES_Programming
* http://gra.dforce3000.de
* http://www.villehelin.com/wla.html
* http://aminet.net/package/dev/cross/65816_20


