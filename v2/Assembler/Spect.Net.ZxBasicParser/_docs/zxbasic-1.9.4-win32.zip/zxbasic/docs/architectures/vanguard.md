#Vanguard

* http://members.aon.at/nkehrer/vantris.html
* http://mamedev.org/source/src/mame/drivers/snk6502.c.html


