#NES

Some of the information collected here can be sinergically developed with the development team from projects like http://playpower.org

A version of HU-Basic is available for NES (Famicom), and can provide interesting and useful information for a compiler. There is also a clone of HU-Basic named G-Basic (mostly available from famiclones) - http://www.youtube.com/watch?v=S8uYcvqJKWA

More information can be found at http://www.zophar.net/documents/nes.html

At http://playpower.pbworks.com/w/page/23989647/gbasic%20manual i tried to start creating a HU-Basic snippet list, which i think can be useful for a compiler development.

some other links:
* http://www.villehelin.com/wla.html
* http://nesdev.parodius.com/
* http://en.wikibooks.org/wiki/NES_Programming


