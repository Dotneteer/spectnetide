#SegaModel2

* http://mamedev.org/source/src/mame/drivers/model2.c.html


